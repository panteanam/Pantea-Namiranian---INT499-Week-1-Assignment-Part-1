import React from 'react';

const Movies = () => {
  return (
    <div>
      <h1>Movies Page</h1>
      <p>This page will contain movie data in Week 4.</p>
    </div>
  );
};

export default Movies;

